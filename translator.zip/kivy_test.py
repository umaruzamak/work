# from kivy.app import App
# from kivy.uix.button import Button

# class TestApp(App):
    # def build(self):
        # return Button(text='Hello World')

# TestApp().run()

from kivy.app import App
from kivy.uix.widget import Widget
from kivy.graphics import *
from kivy.uix.label import Label
from kivy.clock import Clock
import datetime
class MyWidget(Widget):
	def __init__(self, **kwargs):
		super(MyWidget, self).__init__(**kwargs)
		self.bind(pos=self.update_canvas)
		self.bind(size=self.update_canvas)
		self.update_canvas()
	def get_x(label, ref_x):
        # Return the x value of the ref/anchor relative to the canvas """
		return label.center_x - label.texture_size[0] * 0.5 + ref_x


	def get_y(label, ref_y):
        # Return the y value of the ref/anchor relative to the canvas """
        # Note the inversion of direction, as y values start at the top of
        # the texture and increase downwards
		return label.center_y + label.texture_size[1] * 0.5 - ref_y	
	def show_marks(self, label):
        # Indicate the position of the anchors with a red top marker
		for name, anc in label.anchors.items():
			with label.canvas:
				Color(1, 0, 0)
				Rectangle(pos=(self.get_x(label, anc[0]),
						self.get_y(label, anc[1])),
						size=(3, 3))
						  
	def	update_canvas(self, *args):
		self.canvas.clear()
		l = Label(text=datetime.datetime.now().strftime("%a, %d %B %Y %I:%M:%S"))
		blue = InstructionGroup()
		blue.add(Color(0, 0, 1, 0.2))
		blue.add(Rectangle(pos=self.pos, size=(100, 100)))

		green = InstructionGroup()
		green.add(Color(0, 1, 0, 0.4))
		green.add(Rectangle(pos=(100, 100), size=(100, 100)))

		# Here, self should be a Widget or subclass
		[self.canvas.add(group) for group in [blue, green]]
		with self.canvas:
			Color(0.5, 0.1, 0.5, 0.5)
			Ellipse(pos = self.pos, size = self.size)

class MyApp(App):
	def build(self):
		label = Label(
			text='[anchor=a]a\nChars [anchor=b]b\n[ref=myref]ref[/ref]',
			markup=True)
		Clock.schedule_once(lambda dt: self.show_marks(label), 1)
		return label
		return MyWidget()

if __name__ == '__main__':
	MyApp().run()